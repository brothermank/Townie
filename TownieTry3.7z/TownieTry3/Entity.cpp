#include "Entity.h"
#include "MapWindow.h"
#include "Timer.h"
#include "Debugger.h"


Entity::Entity(LTexture text, MapWindow * map, double speed , Vector2 pos, EntityT t) {
	WObject(text);
	n = Navigator(map);
	this->speed = speed;
	this->pos = pos;
	type = t;
}
Entity::Entity(SDL_Renderer * rend, string textureType, string name, MapWindow * map,double speed, Vector2 pos, EntityT t) {
	WObject(rend, textureType, name);
	n = Navigator(map);
	this->speed = speed;
	this->pos = pos;
	type = t;
}
Entity Entity::copy() {
	Entity t;
	t.speed = this->speed;
	t.pos = this->pos;
	t.texture = this->texture;
	t.path = this->path;
	t.n = Navigator(this->n.world);
	t.type = this->type;
	return t;
}


void Entity::update() {
	FollowPath();
}
void Entity::FollowPath() {
	//move along path
	if (path.size() > 0) {
		Vector2 direction = path[0].pos - pos;
		double distance = direction.magnitude();
		direction.normalize();
		if (dTime * speed > distance) {
			//Debugger::print("arrived... Settin pos: " + toString(path.checkpoints[0].pos.x) + "," + toString(path.checkpoints[0].pos.y) + "\n\n\n\n\n\n");
			pos = path[0].pos;
			//Debugger::print("Dtime: " + toString(dTime) + " speed:" + toString(speed) + " lengthTravelled: " + toString(direction.magnitude()) + "\n");
			path.pop();
		}
		else {
			pos += (direction * dTime * speed);
		}
	}
}

int Entity::RecieveAttack(Entity * e) {
	health -= e->dmg;
	if (health <= 0) {//If dead
		e->changeMoney(money);
		//remove reference from world
		n.world->removeEntity(this);
		//Return that this entity is dead
		return 1;
	}
	return 0;
}
