#pragma once
#include <stdio.h>
#include <SDL.h>

extern double dTime;
