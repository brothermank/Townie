#pragma once
#include "Structure.h"
#include <vector>
#include "Entity.h"
#include <memory>


enum TradeGoods { GUndefined = 0, Armor_t = 1, Weapon_t = 2 };

class Store : public Structure {
public:
	Store(Structure s, Vector2 position = Vector2(0, 0)) : Structure(s) { type = Store_t; pos = position; }
	Store(LTexture text, Vector2 position = Vector2(0, 0)) : Structure(text, Store_t, position) {}
	Store(SDL_Renderer * rend, string textureType, string name, Vector2 position = Vector2(0, 0)) : Structure(rend, textureType, name, Store_t, position) {}

	bool SellItem(int itemIndex, Entity customer);
	bool BuyItem(shared_ptr<Item> i, Entity customer);
	void changeMoney(int amount) { money += amount; }

	vector<TradeGoods> itemsForSale;
	vector<shared_ptr<Item>> items;

	Vector2 entrancePoint;

private:
	double money;
};