#include "WObject.h"

WObject::WObject(LTexture text, Vector2 pos) {
	texture = text;
	id = rand();
	this->pos = pos;
}


WObject::WObject(SDL_Renderer * rend, string textureType, string name, Vector2 pos) {
	texture = LTexture(rend, textureType, name);
	id = rand();
	this->pos = pos;
}
