#define frameCap 90

#include "EngineMain.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <string>
#include "Debugger.h"
#include "Timer.h"
#include "Hero.h"
#include "Monster.h"
#include <memory>
#include "GUI.h"
//#include <SDL_ttf.h>
double dTime;
Uint32 timeLast = 0;

Game::Game() {
	initGame();
	shared_ptr<MapWindow> temp(new MapWindow(gWindow, gRenderer));
	currentWindow = temp;
	loadAllTiles();
	Map map = LoadMap("Placeholder");
	map.loadTiles(tiles);
	loadLevel(map);
	loadAllEntities();
	//currentWindow->registerEntity(Hero(entityTemplates[0].copy()));
	currentWindow->registerEntity(make_shared<Monster>(entityTemplates[0].copy(), 10));
	currentWindow->entities[0]->pos = Vector2(2, 2);
	currentWindow->registerEntity(make_shared<Hero>(entityTemplates[0].copy(), 10));
	currentWindow->guiElements.push_back(shared_ptr<GButtonSelectTile>(new GButtonSelectTile(currentWindow, gRenderer, textures[0], 0, Vector2(1560, 20), Vector2(150, 75))));
	currentWindow->guiElements.push_back(shared_ptr<GButtonSelectTile>(new GButtonSelectTile(currentWindow, gRenderer, textures[1], 1, Vector2(1730, 20), Vector2(150, 75))));
	currentWindow->guiElements.push_back(shared_ptr<GButtonSelectTile>(new GButtonSelectTile(currentWindow, gRenderer, textures[2], 2, Vector2(1560, 115), Vector2(150, 75))));
	currentWindow->guiElements.push_back(shared_ptr<GButtonSelectTile>(new GButtonSelectTile(currentWindow, gRenderer, textures[3], 3, Vector2(1730, 115), Vector2(150, 75))));
	currentWindow->guiElements.push_back(shared_ptr<GButtonSelectTile>(new GButtonSelectTile(currentWindow, gRenderer, textures[4], 4, Vector2(1560, 200), Vector2(150, 75))));
	currentWindow->guiElements.push_back(shared_ptr<GButtonSelectBrushSize>(new GButtonSelectBrushSize(currentWindow, gRenderer, textures[4], false, Vector2(1560, 400), Vector2(150, 150))));
	currentWindow->guiElements.push_back(shared_ptr<GButtonSelectBrushSize>(new GButtonSelectBrushSize(currentWindow, gRenderer, textures[4], true, Vector2(1730, 400), Vector2(150, 150))));
}

void Game::start() {
	//currentWindow->monsters[0].pos = Vector2(2, 2);
	//saveLevel();
	mainLoop();
}
bool Game::initGame() {
	bool success = true;

	gWindow = SDL_CreateWindow("SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
	if (gWindow == NULL) {
		printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
	}
	else {
		gRenderer = SDL_CreateRenderer(&*gWindow, -1, SDL_RENDERER_ACCELERATED);
		if (gRenderer == NULL){
			printf("Renderer could not be created! SDL Error: %s\n", SDL_GetError());
			success = false;
		} else {
			SDL_SetRenderDrawColor(gRenderer, 0xFF, 0xFF, 0xFF, 0xFF);
		}
		gScreenSurface = SDL_GetWindowSurface(&*gWindow);
	}
	LoadFont("Raleway-Regular");
	return success;
}
void Game::closeGame() {

	//Free loaded image
	int textureCount = textures.size();
	for (int i = textureCount - 1; i > 0; i--) {
		SDL_DestroyTexture(textures[i].mTexture);
	}
	textures.erase(textures.begin(), textures.end());

	//Destroy window    
	SDL_DestroyRenderer(gRenderer);
	SDL_DestroyWindow(gWindow);
	gWindow = NULL;
	gRenderer = NULL;

}

void Game::loadLevel(Map m) {
	MapWindow w = MapWindow(gWindow, gRenderer, m);
	*currentWindow = w;
}
void Game::loadLevel() {
	loadLevel(Map(tiles));
}

void Game::mainLoop() {
	bool quit = false;
	SDL_Event e;
	SDL_StartTextInput();

	timeLast = SDL_GetTicks();
	double timer1 = 0;
	int frames = 0;

	bool heldClick = false;

	while (!quit) {
		//Handle events on queue
		while (SDL_PollEvent(&e) != 0)
		{
			//User requests quit
			if (e.type == SDL_QUIT) {
				quit = true;
			}
			else if (e.type == SDL_KEYDOWN) {
				currentWindow->ReceiveHotkeyInput(e);
			}
			else if (e.type == SDL_TEXTINPUT){
				currentWindow->ReceiveTextInput(e);
			}
			//TODO: Transfer handle to mapWindow
			else if (e.type == SDL_MOUSEWHEEL) {
				currentWindow->zoom *= (pow(1.1,e.wheel.y));
			}
		}

		//Handle clicks
		int *x, *y;
		int a1 = 0, a2 = 0;
		x = &a1;
		y = &a2;
		Uint32 bmap = SDL_GetMouseState(x, y);
		currentWindow->ReceiveClick(Vector2(*x, *y), bmap, heldClick);
		if (bmap & SDL_BUTTON(SDL_BUTTON_LEFT) && !heldClick) {
			Debugger::print("Click\n");
			heldClick = true;
		}
		else if (!(bmap & SDL_BUTTON(SDL_BUTTON_LEFT)) && heldClick) {
			Debugger::print("Unclick\n");
			heldClick = false;
		}
		
		//Update window
		currentWindow->update();

		//Timer handling
		dTime = 0;
		while (dTime < 1.0 / frameCap) {
			dTime = (SDL_GetTicks() - timeLast) * 0.001;
		}
		timeLast += dTime * 1000;
		timer1 += dTime;
		frames++;

	}

	closeGame();
}

void Game::loadAllTiles() {
	textures.push_back(LTexture(gRenderer, "Texture", "Black"));
	textures.push_back(LTexture(gRenderer, "Texture", "Grass1"));
	textures.push_back(LTexture(gRenderer, "Texture", "Road1"));
	textures.push_back(LTexture(gRenderer, "Texture", "Road2"));
	textures.push_back(LTexture(gRenderer, "Texture", "Road3"));

	tiles.push_back(Tile(&textures[0], 100));
	tiles.push_back(Tile(&textures[1], 4));
	tiles.push_back(Tile(&textures[2]));
	tiles.push_back(Tile(&textures[3]));
	tiles.push_back(Tile(&textures[4]));
}
void Game::loadAllEntities() {
	entityTemplates.push_back(Entity(gRenderer, "Character", "Viking", &*currentWindow, 1, Vector2(0,0), Hero_t));
}

void Game::saveLevel() {
	currentWindow->saveMap();
}