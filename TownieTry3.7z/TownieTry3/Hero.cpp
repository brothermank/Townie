#include "Hero.h"
#include "Monster.h"
#include "MapWindow.h"
#include "Debugger.h"
#include "StringHelper.h"

void Hero::TargetNearestMonster() {
	shared_ptr<Monster> nearestMonster = NULL;
	double distance = 9999;
	for (size_t i = 0; i < n.world->entities.size(); i++) {
		if (n.world->entities[i]->type == Monster_t && distanceTo(&(*n.world->entities[i])) < distance) {
			distance = distanceTo(&(*n.world->entities[i]));
			nearestMonster = static_pointer_cast<Monster>(n.world->entities[i]);
		}
	}
	if (nearestMonster != NULL) {
		hasT = 1;
		target = nearestMonster;
		path = n.findPath(pos, target->pos);
	}
	
}
void Hero::AttackTarget(){
	int q = target->RecieveAttack(this);
	
	if (q) { //Attack... If the monster died
		if (target->getMoney() > 0) {//Take money
			changeMoney(target->getMoney());
			target->changeMoney(-target->getMoney());
		}
		//Remove reference
		target = NULL;
		hasT = false;
	}
}

void Hero::update() {
	if (hasT == 0) {
		TargetNearestMonster();
	}
	if (hasT == 1 && distanceTo(target->pos) < range) {
		AttackTarget();
	}
	else {
		FollowPath();
	}
}