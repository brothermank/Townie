#pragma once

class Item {
public:
	virtual double getValue() { return value * power; }

private:
	double value, power = 1;
};