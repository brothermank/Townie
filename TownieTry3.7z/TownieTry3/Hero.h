#pragma once
#include "Entity.h"
#include <memory>
class Monster;
class Hero : public Entity {
public:
	Hero(Entity baseEntity, double Health = 10, double Money = 1, double Dmg = 1, double Range =  0.2) : Entity(baseEntity.copy())
	{
		type = Hero_t; money = Money; dmg = Dmg; health = Health; range = Range; hasT = 0;
	}

	void update();
	void TargetNearestMonster();

	
private:
	void AttackTarget();

	std::shared_ptr<Monster> target;
	int hasT;
};
