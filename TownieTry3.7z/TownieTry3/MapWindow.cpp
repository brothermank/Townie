#include "MapWindow.h"
#include <math.h>
#include "Debugger.h"

SDL_RendererFlip flipType = SDL_FLIP_NONE;

MapWindow::MapWindow(SDL_Window * wind, SDL_Renderer * renderer) : Window(wind, renderer) {
	wposx = 0;
	wposy = 0;
	zoom = 1;
	guiElements.push_back(saveText);
}
MapWindow::MapWindow(SDL_Window * wind, SDL_Renderer * renderer, Map m):Window(wind, renderer) {
	wposx = 0;
	wposy = 0;
	zoom = 1;
	map = m;
	shared_ptr<GTextField> temp(new GTextField(rend));
	saveText = temp;
	guiElements.push_back(saveText);
}

void MapWindow::DrawMap() {

	int scrw, scrh;
	scrw = SDL_GetWindowSurface(window)->w;;
	scrh = SDL_GetWindowSurface(window)->h;
	
	int xl;
	int xh;
	int yl;
	int yh;
	xl = (int)(screnPosToMapPos(Vector2(-tilew, scrh)).x - 1);
	xh = (int)(screnPosToMapPos(Vector2(scrw, -tileh)).x + 1);
	yl = (int)(screnPosToMapPos(Vector2(-tilew, -tileh)).y - 1);
	yh = (int)(screnPosToMapPos(Vector2(scrw, scrh)).y + 1);

	double offx = fmod(wposx, 1.0f);
	double offy = fmod(wposy, 1.0f);

	//Clear screen
	SDL_RenderClear(rend);
	Tile * t;

	//Render texture to screen
	for (int y = yh; y > yl; y--) {
		for (int x = xl; x < xh; x++) {
			
			Vector2 scrpos = mapPosToScreenPos(Vector2(x,y));
			
			if (scrpos.x >= -tilew && scrpos.x <= scrw && scrpos.y >= -tileh && scrpos.y <= scrh) {
				t = map.getTileAt(x, y);
				t->texture->render(scrpos, tileh, rend);
				//SDL_RenderCopy(rend, t->texture.mTexture, NULL, &renderArea);
			}
		}
	}
}


void MapWindow::saveMap() {
	map.save();
}

Vector2 MapWindow::screnPosToMapPos(Vector2 pos) {

	Vector2 rpos;
	rpos.x = ((pos.x - tilew * 0.25f) / tilew - (pos.y - tileh * 0.25f) / tileh) + 0.5f + wposx;
	rpos.y = (pos.x - tilew * 0.25f) / tilew + (pos.y - tileh * 0.25f) / tileh + wposy; 
	return rpos;
}

Vector2 MapWindow::mapPosToScreenPos(Vector2 pos) {
	Vector2 posr;
	pos.x -= wposx;
	pos.y -= wposy;

	posr.x = pos.x * tilew * 0.5f + pos.y * tilew * 0.5f;
	posr.y = pos.y * tileh * 0.5f - pos.x * tileh * 0.5f;
	//Debugger::print("In calculation, scrx:" + toString(results[0]) + " scry:" + toString(results[1]) + " with input, x:" + toString(x) + " y:" + toString(y) + "\n");
	return posr;
}
Map* MapWindow::getMap() {
	return &map;
}

void MapWindow::DrawEntities() {
	int scrw = SDL_GetWindowSurface(window)->w;;
	int scrh = SDL_GetWindowSurface(window)->h;
	for (size_t i = 0; i < entities.size(); i++) {
		Vector2 scrpos = mapPosToScreenPos(entities[i]->pos + Vector2(0,1));
		if (scrpos.x >= -tilew && scrpos.x <= scrw && scrpos.y >= -tileh && scrpos.y <= scrh) {
			double scale = entities[i]->texture.mWidth * 1.0f / entities[i]->texture.mHeight;
			int width = (int)(EntityHeight * scale);
			entities[i]->texture.render(scrpos, EntityHeight, rend, NULL, NULL, Vector2(0.5,1));
		}
	}
}

void MapWindow::UpdateEntities() {
	for (size_t i = 0; i < entities.size(); i++) {
		Hero* h = NULL;
		switch (entities[i]->type) {
		case Undefined:
			entities[i]->update();
			break;	
		case Hero_t:
			entities[i]->update();
			//h = entities[i];
			//h->update();
			break;
		case Monster_t:
			entities[i]->update();
			//((Monster*)(&entities[i]))->update();
			break;
		default:
			break;
		}
	}
}

void MapWindow::registerEntity(shared_ptr<Entity> e) {
	entities.push_back(e);
}

void MapWindow::removeEntity(Entity * e) {
	for (size_t i = 0; i < entities.size(); i++) {
		if (entities[i]->id == e->id) {
			entities.erase(entities.begin() + i);
		}
	}
}
void MapWindow::update() {
	UpdateEntities();
	DrawMap();
	DrawEntities();
	DrawGui();
	updateScreen();
	
}

bool MapWindow::ReceiveClick(Vector2 pos, Uint32 mask, bool buttonDown) {
	bool guiOverlayed = Window::ReceiveClick(pos, mask, buttonDown);
	if (!guiOverlayed) {
		if (mask & SDL_BUTTON(SDL_BUTTON_LEFT) && !buttonDown) {
			heldLeft = true;
			pos = screnPosToMapPos(pos);
			for (int i = 0; i < paintSize * 2 - 1; i++) {
				for (int j = 0; j < paintSize * 2 - 1; j++) {
					map.setTileAt((int)pos.x - paintSize + 1 + i, (int)pos.y - paintSize + 1 + j, paintingKey);

				}
			}

		}
		else if (heldLeft) {
			heldLeft = false;
			map.nextAction();
		}
		if (mask & SDL_BUTTON(SDL_BUTTON_RIGHT)) {
			if (!heldRight) {
				heldRight = true;
				/*Vector2 pos;
				pos = currentWindow.screnPosToMapPos(Vector2((double)*x, (double)*y));
				paintingKey = currentWindow.getMap()->getValueAt((int)pos.x, (int)pos.y);
				*/
				entities[0]->path = entities[0]->n.findPath(entities[0]->pos, screnPosToMapPos(pos));
			}
		}
		else if (heldRight) {
			heldRight = false;
			map.nextAction();
		}
	}
	return guiOverlayed;
}

void MapWindow::ReceiveHotkeyInput(SDL_Event e) {
	Window::ReceiveHotkeyInput(e);
	SDL_Keycode key = e.key.keysym.sym;

	//Select surfaces based on key press
	switch (key) {
	case SDLK_UP:
		wposy -= scrollSpeed;
		wposx += scrollSpeed;
		break;
	case SDLK_DOWN:
		wposy += scrollSpeed;
		wposx -= scrollSpeed;
		break;
	case SDLK_LEFT:
		wposy -= scrollSpeed;
		wposx -= scrollSpeed;
		break;
	case SDLK_RIGHT:
		wposy += scrollSpeed;
		wposx += scrollSpeed;
		break;
	case SDLK_d:
		paintingKey = (paintingKey + 1) % totalTextures;
		break;
	case SDLK_a:
		paintingKey--;
		if (paintingKey < 0) paintingKey = totalTextures - 1;
		break;
	case SDLK_z:
		getMap()->undoLastChange();
		break;
	default:
		break;
	}
	if (key == SDLK_s && SDL_GetModState() & KMOD_CTRL) {
		getMap()->name = saveText->getText();
		getMap()->save();
	}
	if (key == SDLK_l && SDL_GetModState() & KMOD_CTRL) {
		getMap()->name = saveText->getText();
		getMap()->load(saveText->getText());
	}
}

void MapWindow::changePaintSize(bool increment) {
	if (increment) {
		paintSize++;
	}
	else {
		paintSize--;
	}
	if (paintSize <= 1) paintSize = 1;
}