#pragma once
#include "WObject.h"

using namespace std;

enum StructT {SUndefined, Store_t};

class Structure : public WObject{
public:

	Structure(StructT Type = SUndefined, Vector2 position = Vector2(0, 0)) : type(Type), WObject(position) {}
	Structure(LTexture text, StructT Type = SUndefined, Vector2 position = Vector2(0,0)) :type(Type), WObject(text, position){}
	Structure(SDL_Renderer * rend, string textureType, string name, StructT Type = SUndefined, Vector2 position = Vector2(0, 0)) :type(Type), WObject(rend, textureType, name){}

	Vector2 position;
	StructT type;

};