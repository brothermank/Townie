#pragma once
#include <SDL.h>
#include <vector>
#include <stack>
#include "StringHelper.h"
#include "ResourceLoader.h"

#define sx 10
#define sy 20
#define fileending ".cmap"

using namespace std;

struct Action {
	vector<int> x;
	vector<int> y;
	vector<int> prevValue;
};

struct Tile {
public:
	double getTravelWeight();

	unsigned int sizeX;
	unsigned int sizeY;
	LTexture* texture;

	Tile(LTexture* text, double ntravelWeight = 1) {
		texture = text;
		sizeX = text->mWidth;
		sizeY = text->mHeight;
		travelWeight = ntravelWeight;
	}

private:
	double travelWeight;
};

class Map {
public:
	Map();
	Map(vector<Tile> textures);
	Map(vector<Tile> textures, string name);
	void loadTiles(vector<Tile> textures);
	int getValueAt(int x, int y);
	Tile* getTileAt(int x, int y);
	void setTileAt(int x, int y, int value);
	double getTravelWeightAt(int x, int y);
	void undoLastChange();
	void nextAction();
	void save();
	void load(string mapName);

	vector<vector<int>> tiles;
	std::vector<Tile> tileTypes;
	string name = "";

private:
	stack<Action> actionStack;

};

Map LoadMap(string mapName);

