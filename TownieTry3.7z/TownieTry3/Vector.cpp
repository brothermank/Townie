#include "Vector.h"
#include <math.h>
#include "Debugger.h"
#include "StringHelper.h"

Vector2 Vector2::copy(Vector2 v) {
	return Vector2(v.x, v.y);
}
Vector2 Vector2::normalize() {
	*this /= this->magnitude();
	return copy(*this);
}
double Vector2::magnitude() {
	return sqrt(pow(x, 2) + pow(y, 2));
}
bool Vector2::isWithin(Vector2 pos, Vector2 size) {
	bool result = pos.x < x && x < pos.x + size.x && pos.y < y && y < pos.y + size.y;
	return result;
}