#pragma once
#include "Entity.h"
class Monster : public Entity {
public:
	Monster(Entity baseEntity, double Health = 10, double Money = 1, double Dmg = 1) : Entity(baseEntity.copy())
	{type = Monster_t; health = Health; money = Money; dmg = Dmg; }
};