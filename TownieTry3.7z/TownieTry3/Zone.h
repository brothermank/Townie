#pragma once
#include "Vector.h"
#include "Entity.h"

class Zone {
public:
	virtual void tick(double time) = 0;
	virtual void onEnter(Entity e) = 0;
	virtual void onExit(Entity e) = 0;

protected:
	Vector2 pos;
	Vector2 size;
};