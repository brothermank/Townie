#pragma once
#include "ResourceLoader.h"

class WObject {
public:
	WObject(Vector2 pos = Vector2(0,0)) : pos(0, 0) { id = rand(); }
	WObject(LTexture text, Vector2 pos = Vector2(0, 0));
	WObject(SDL_Renderer * rend, string textureType, string name, Vector2 pos = Vector2(0, 0));

	int id;
	Vector2 pos;

	double distanceTo(WObject * e) { return (((*e).pos - this->pos).magnitude()); }
	double distanceTo(Vector2 pos) { return ((pos - this->pos).magnitude()); }
	
	LTexture texture;
};