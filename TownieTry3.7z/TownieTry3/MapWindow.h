#pragma once
#define EntityHeight (70 * zoom)
#define tilew (400 * zoom)
#define tileh (200 * zoom)
#define scrollSpeed 0.4f
#define totalTextures 5

#include <SDL.h>
#include <SDL_render.h>
#include "Map.h"
#include "Monster.h"
#include "Hero.h"
#include <memory>
#include "Window.h"

class MapWindow : public Window {
public:
	MapWindow(SDL_Window * window, SDL_Renderer * renderer);
	MapWindow(SDL_Window * window, SDL_Renderer * renderer, Map m);
	double wposx, wposy;
	double zoom;
	void DrawMap();
	void saveMap();
	void DrawEntities();
	void UpdateEntities();
	Vector2 screnPosToMapPos(Vector2 pos);
	Vector2 mapPosToScreenPos(Vector2 pos);
	Map * getMap();
	void update();
	bool ReceiveClick(Vector2 pos, Uint32 mask, bool buttonDown);
	void ReceiveHotkeyInput(SDL_Event e);
	void changePaintSize(bool increment);

	void registerEntity(shared_ptr<Entity> e);
	void removeEntity(Entity * e);
	vector<shared_ptr<Entity>> entities; //Should use int/ID based hashmaps for faster removal (instead of searching through entire vector)
	int paintingKey = 1;

private:
	Map map;
	bool heldLeft = false;
	bool heldRight = false;
	shared_ptr<GTextField> saveText;
	int paintSize = 2;
};