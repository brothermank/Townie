#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include <vector>
#include "MapWindow.h"

#define SCREEN_WIDTH 1920
#define SCREEN_HEIGHT 1080

using namespace std;

class Game {
public:
	Game();
	void start();
	bool initGame();
	void closeGame();
	void mainLoop();
	void loadAllTiles();
	void loadAllEntities();
	void loadLevel(MapWindow window);
	void loadLevel(Map m);
	void loadLevel();
	void saveLevel();
	vector<LTexture> textures;
	vector<Tile> tiles;
	vector<Entity> entityTemplates;

private:
	SDL_Window * gWindow;
	SDL_Surface* gScreenSurface = NULL;
	SDL_Renderer* gRenderer = NULL;
	shared_ptr<MapWindow> currentWindow;

};
